from hdeval import HDEvalInterface

hd_eval = HDEvalInterface()

